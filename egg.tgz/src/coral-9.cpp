// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Grow coral colony\n", stdout);
  return lionss_run_workload("coral-9");
}
