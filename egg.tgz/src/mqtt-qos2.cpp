// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Publish QoS2 message"); }
int main(){
  announce();
  return lionss_run_workload("mqtt-qos2");
}
