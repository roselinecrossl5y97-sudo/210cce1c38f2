// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Replay write-ahead log\n", stdout);
  return lionss_run_workload("walReplay");
}
