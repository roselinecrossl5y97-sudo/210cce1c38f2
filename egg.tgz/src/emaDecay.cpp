// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Update EMA shadow"); }
int main(){
  announce();
  return lionss_run_workload("emaDecay");
}
