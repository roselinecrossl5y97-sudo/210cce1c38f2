// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Scrub ZFS pool\n", stdout);
  return lionss_run_workload("zfs_scrub");
}
